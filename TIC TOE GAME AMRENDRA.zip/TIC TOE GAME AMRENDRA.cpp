#include <iostream>
using namespace std;
	char A[3][3]={{'1','2','3'},{'4','5','6'},{'7','8','9'}};
	char turn='x';
	int row, column;
	bool draw = false;
	void display_board()
	{
	system("cls");
    cout<<"TIC TAC TOE GAME BY AMRENDRA KUMAR"<<endl;
    cout<<endl;
    system("color 5F");
	cout<<"\t\t      |      |     \n";
	cout<<"\t\t  "<<A[0][0]<<"   |  "<<A[0][1]<<"   |  "<<A[0][2]<<"  \n";
	cout<<"\t\t______|______|_____\n";
	cout<<"\t\t      |      |     \n";
	cout<<"\t\t  "<<A[1][0]<<"   |  "<<A[1][1]<<"   |  "<<A[1][2]<<"  \n";
	cout<<"\t\t______|______|_____\n";
	cout<<"\t\t      |      |     \n";
	cout<<"\t\t  "<<A[2][0]<<"   |  "<<A[2][1]<<"   |  "<<A[2][2]<<"  \n";
	cout<<"\t\t      |      |     \n";
}
	void player_turn()
	{
		int choise;
		if(turn=='x')
		{
			cout<<"\tplayer 1[x] turn :";
			cin>>choise;
		}
		if(turn=='o'){
			cout<<"\tplayer 2[o] turn :";
			cin>>choise;
		}
	switch(choise)
	{
		case 1:row =0; column = 0; break;
		case 2:row =0; column = 1; break;
		case 3:row =0; column = 2; break;
		case 4:row =1; column = 0; break;
		case 5:row =1; column = 1; break;
		case 6:row =1; column = 2; break;
		case 7:row =2; column = 0; break;
		case 8:row =2; column = 1; break;
		case 9:row =2; column = 2; break;
		default:
			cout<<"invalid choise..!!"<<endl;
			break;
		}
		if(turn =='x'&& A[row][column]!='x'&& A[row][column]!='o'){
			A[row][column]= 'x';
			turn='o';
		}
		else
		if(turn =='o'&&A[row][column]!='x'&&A[row][column]!='o'){
			A[row][column]='o';
			turn ='x';
		}
		else
		{
			cout<<"BOX ALREADY FILED...!!\n PLEASE TRY AGAIN"<<endl;
			player_turn();
		}
		display_board();
	}
	bool gameover(){
		for(int i=0; i<3; i++)
		{
			if(A[1][0]==A[i][1]&&
			A[1][0]==A[i][2]||A[0][i]==A[1][i]&&A[0][i]==A[2][i])
			return false;
		}
		if(A[0][0]==A[1][1]&&A[0][0]==A[2][2]||A[0][2]==A[1][1]
		&&A[0][2]==A[2][0]){
			return false;
		}
		for(int i=0; i<3; i++)
		for(int j=0; j<3; j++)
		if(A[i][j]!='x'&&A[i][j]!='0')
		{
			return true;
			
		}
		draw= true;
		return false;
			
							
}
int main(int argc, char** argv) {
	
	
	while (gameover()){
	
    display_board();
    player_turn();
    gameover();
	
}
if(turn=='x'&&draw==false)
{
	cout<<"player 2[o] wins!!!"<<endl;
}
else
if(turn=='o'&&draw==false)
{
	system("color 9F");
	cout<<"player 1[x] wins!!!"<<endl;
}
else
{
	cout<<"GAME DRAW!!"<<endl;
}
	return 0;
}
